package com.example.connect_adu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConnectAduApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConnectAduApplication.class, args);
	}

}
