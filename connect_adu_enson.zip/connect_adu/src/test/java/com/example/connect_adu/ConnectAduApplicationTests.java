package com.example.connect_adu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConnectAduApplicationTests {

	@Test
	void contextLoads() {
	}

}
