package com.example.connect_adu.models;

public enum ERole {
	  ROLE_USER,
	  ROLE_MODERATOR,
	  ROLE_ADMIN
	}
